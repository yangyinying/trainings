﻿namespace Catalog.API.Application.Dtos
{
    public class ArtistDto
    {
        public int ArtistId { get; set; }
        public string Name { get; set; }
    }
}