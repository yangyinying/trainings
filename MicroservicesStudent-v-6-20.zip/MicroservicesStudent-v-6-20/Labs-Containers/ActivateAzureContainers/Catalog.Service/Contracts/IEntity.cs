﻿namespace Catalog.API.Contracts
{
    public interface IEntity
    {
        int Id { get; set; }
    }
}