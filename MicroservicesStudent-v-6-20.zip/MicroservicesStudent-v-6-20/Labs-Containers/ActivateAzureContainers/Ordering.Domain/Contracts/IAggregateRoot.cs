﻿namespace Ordering.Domain.Contracts
{
    public interface IAggregateRoot
    {
    }
}