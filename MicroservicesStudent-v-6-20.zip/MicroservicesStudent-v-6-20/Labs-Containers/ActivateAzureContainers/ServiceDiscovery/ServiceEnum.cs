﻿namespace ServiceDiscovery
{
    public enum ServiceEnum
    {
        ApiGateway,
        Ordering,
        Catalog,
        Basket
    }
}