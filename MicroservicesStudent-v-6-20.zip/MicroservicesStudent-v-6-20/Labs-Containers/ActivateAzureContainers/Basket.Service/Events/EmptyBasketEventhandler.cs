﻿using System;
using System.Text;
using System.Threading.Tasks;
using Basket.API.Contracts;
using EventBus.Events;
using Microsoft.Azure.ServiceBus;
using Newtonsoft.Json;

namespace Basket.API.Events
{
    public class EmptyBasketEventHandler : IIntegratedEventHandler
    {
        private readonly IBasketBusinessServices _basketDomain;

        public EmptyBasketEventHandler(IBasketBusinessServices businessServices)
        {
            _basketDomain = businessServices;
        }

        public async Task HandleAsync(Message message)
        {
            try
            {
                // Unpack mesage and extract the message payload
                var body = Encoding.UTF8.GetString(message.Body);
                var basketInformation = JsonConvert.DeserializeObject<EmptyBasketEvent>(body);

                // Ensure that the third parameter is marked as true as we need
                // to alert the Empty Basket method that this order has been created.
                await _basketDomain.EmptyBasket(basketInformation.BasketID,
                     basketInformation.CorrelationToken, true);
            }
            catch (Exception ex)
            {
                throw new Exception($"Exception unpacking EmptyBasket Event in Eventhandler : {ex.Message}");
            }

            await Task.CompletedTask;
        }
    }
}