﻿using System;
using System.Text;
using System.Threading.Tasks;
using Basket.API.Contracts;
using Basket.API.Domain;
using EventBus.Events;
using Microsoft.Azure.ServiceBus;
using Newtonsoft.Json;

namespace Basket.API.Events
{
    /// <summary>
    ///     Handles ProductChanged Event rasied from Catalog Service
    /// </summary>
    public class ProductChangedEventHandler : IIntegratedEventHandler
    {
        private readonly IBasketBusinessServices _basketBusinessServices;

        public ProductChangedEventHandler(IBasketBusinessServices basketBusinessServices)
        {
            _basketBusinessServices = basketBusinessServices;
        }

        public async Task HandleAsync(Message message)
        {
            try
            {
                // Unpack mesage
                // Extract correlation token
                message.UserProperties.TryGetValue("correlationToken", out var correlationToken);

                // Extract message payload
                var body = Encoding.UTF8.GetString(message.Body);

                // Deserialize message payload
                var payload = JsonConvert.DeserializeObject<ProductChangedEvent>(body);

                // Transform event data to Product data
                var product = new Product
                {
                    Id = payload.Id,
                    Title = payload.Title,
                    ArtistName = payload.ArtistName,
                    GenreName = payload.GenreName,
                    Price = payload.Price,
                    ParentalCaution = payload.ParentalCaution,
                    ReleaseDate = payload.ReleaseDate,
                    Cutout = payload.Cutout,
                    Upc = payload.Upc
                };

                await _basketBusinessServices.ProductChanged(product, correlationToken?.ToString());
            }
            catch (Exception ex)
            {
                throw new Exception($"Exception unpacking ProductChanged Event in Eventhandler : {ex.Message}");
            }

            await Task.CompletedTask;
        }
    }
}