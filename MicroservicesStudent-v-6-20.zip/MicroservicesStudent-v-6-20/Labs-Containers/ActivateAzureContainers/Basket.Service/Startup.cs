﻿using System;
using System.IO;
using Basket.API.Application.Filters;
using Basket.API.Application.StartupExtensions;
using Basket.API.Contracts;
using Basket.API.Domain;
using Basket.API.Events;
using EventBus.EventBus;
using EventBus.Events;
using Microsoft.ApplicationInsights.Extensibility;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.PlatformAbstractions;
using RestCommunication;
using ServiceDiscovery;
using Swashbuckle.AspNetCore.Swagger;

namespace Basket.API
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            // Register cloud resources via extension methods
            services.RegisterMessageBroker(Configuration);
            services.RegisterStorageAccount(Configuration);

            // Resgister concrete dependencies
            services.AddSingleton<IServiceLocator, ServiceLocator>();
            services.AddSingleton<IHttpContextAccessor, HttpContextAccessor>();
           
            services.AddScoped<IBasketBusinessServices, BasketBusinessServices>();


            services.AddMvc(config =>
                {
                    // Attach Customer Exception Filter
                    config.Filters.Add(typeof(BasketCustomExceptionFilter));
                }
            );

            services.AddSwaggerGen(c =>
            {
                c.SwaggerDoc("v1", new Info
                {
                    Title = "Shopping Basket API",
                    Version = "v1",
                    Description =
                        "Exposed as microservice for the Microsoft ActivateAzure with Microservices and Containers Workshop. Manages Shopping Basket."
                });
                // Set the comments path for the Swagger JSON and UI.
                var basePath = PlatformServices.Default.Application.ApplicationBasePath;
                var xmlPath = Path.Combine(basePath, "Basket.API.xml");
                c.IncludeXmlComments(xmlPath);
            });

            // Swtich to enable Resilient RestClient component
            if (Configuration.GetValue<string>("UseResilientRestClient") == bool.TrueString)
            {
                services.AddSingleton<IRestClient, ResilientRestClient>();
            }
            else
            {
                // User does not want to use Resilient RestClient library
                services.AddScoped<IRestClient, RestClient>();
            }
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IHostingEnvironment env, IServiceProvider serviceProvider,
            ILoggerFactory loggerFactory)
        {
            loggerFactory.AddConsole(Configuration.GetSection("Logging"));
            loggerFactory.AddDebug();

            if (env.IsDevelopment())
                app.UseDeveloperExceptionPage();

            app.UseMvc();

            app.UseSwagger();

            app.UseSwaggerUI(c => { c.SwaggerEndpoint("/swagger/v1/swagger.json", "Shopping Basket API V1"); });

            ConfigureEventBus(app, serviceProvider);

            //// Disable Application Insights Telemetry Data Collection for now
            //var configuration = app.ApplicationServices.GetService<TelemetryConfiguration>();
            //configuration.DisableTelemetry = true;
        }

        // ServiceCollection doesn’t provide GetService or GetRequiredService methods directly.
        // Rather, those methods are available from the IServiceProvider.
        private void ConfigureEventBus(IApplicationBuilder app, IServiceProvider serviceProvider)
        {
            var eventBus = app.ApplicationServices.GetRequiredService<IEventBus>();
            eventBus.ServiceProvider = serviceProvider;
                       
            eventBus.Subscribe(MessageEventEnum.InvokeEmptyBasketEvent,
                typeof(EmptyBasketEventHandler));
            eventBus.Subscribe(MessageEventEnum.ProductChangedEvent,
                typeof(ProductChangedEventHandler));
        }
    }
}