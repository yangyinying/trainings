﻿namespace Basket.API.Domain
{
    public class BasketItemRemoved
    {
        public string Message { get; set; }
        public decimal BasketTotal { get; set; }
        public int BasketCount { get; set; }
        public int ItemCount { get; set; }
        public int DeleteId { get; set; }
    }
}