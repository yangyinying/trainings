﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Basket.API.Contracts;
using Basket.API.Events;
using EventBus.EventBus;
using EventBus.Events;
using Microsoft.Extensions.Logging;
using RestCommunication;
using ServiceDiscovery;

namespace Basket.API.Domain
{
    /// <summary>
    ///     Shopping basket domain business object
    /// </summary>
    public class BasketBusinessServices : IBasketBusinessServices
    {
        private const string ProductPartitionKey = "MusicProduct";
        private readonly IBaseRespository<BasketItemEntity> _basketRepository;
        private readonly IEventBus _eventBus;
        private readonly ILogger _logger;
        private readonly IBaseRespository<ProductEntity> _productRepository;
        private readonly IRestClient _restClient;

        public BasketBusinessServices(IBaseRespository<BasketItemEntity> basketRepository,
            IBaseRespository<ProductEntity> productRepository,
            ILogger<BasketBusinessServices> logger,
            IRestClient restClient,
            IEventBus eventBus)
        {
            _basketRepository = basketRepository;
            _productRepository = productRepository;
            _logger = logger;
            _restClient = restClient;
            _eventBus = eventBus;
        }

        /// <summary>
        ///     Get all shopping baskets
        /// </summary>
        /// <param name="correlationToken">Tracks request - can be any value</param>
        /// <returns>BasketItemEntity</returns>
        public async Task<List<BasketItemEntity>> GetAllBaskets(string correlationToken)
        {
            var basket = await _basketRepository.GetList(correlationToken);
            return basket;
        }

        /// <summary>
        ///     Gets specified shopping basket by Basket Id
        /// </summary>
        /// <param name="correlationToken">Tracks request - can be any value</param>
        /// <param name="basketId">Id of shopping basket</param>
        /// <returns>BasketItemEntity</returns>
        public async Task<List<BasketItemEntity>> GetBasketItems(string basketId, string correlationToken)
        {
            var basket = await _basketRepository.GetList(basketId, correlationToken);
            return basket;
        }

        /// <summary>
        ///     Add single line item to shopping basket
        /// </summary>
        /// <param name="product">Product to add</param>
        /// <param name="productId">Id of product to add</param>
        /// <param name="correlationToken">Tracks request - can be any value</param>
        /// <param name="basketId">Id of shopping basket</param>
        /// <returns>BasketItemEntity</returns>
        public async Task<BasketItemEntity> AddItemToBasket(Product product, int productId, string correlationToken,
            string basketId)
        {
            // Determine if item already exists in shopping basket
            var basketItem = await _basketRepository.GetItem(basketId, productId.ToString(), correlationToken);
            
            // Add idempotent write-check. Ensure that update with same correlation token does not already exist. 
            // This could happen if we've already committed the write, but have gotten caught-up in retry logic.
            if (basketItem?.CorrelationToken != null && basketItem.CorrelationToken == correlationToken)
            {
                // This item has already been added to the cart
                _logger.LogWarning(
                    "Product Id {id} has already been added to shopping basket {basket} for request {token}", productId,
                    basketId, correlationToken);
                return basketItem;
            }

            //******************************************************************************
            //* Direct HTTP call to retreieve product information from the Catalog service.
            //* Simple to implement, but considered an antipattern.
            ////product = _restClient.GetAsync<Product>(ServiceEnum.Catalog,
            ////    $"api/Catalog/Music/{correlationToken}/{productId}").Result;

            ////// Fallback logic if product cannot be found
            ////if (product == null)
            ////{
            ////    _logger.LogWarning($"Cannot locate product information for item {productId}");
            ////    throw new Exception($"Cannot add item to shopping basket: Product #{productId} does not exist.");
            ////}

            //******************************************************************************
            //* Materialized View Pattern call to retrieve product information.
            //* Fetches product data from a read-only view of product data included in
            //* the shopping basket service, but owned and maintained by the Catalog service
            //* Keep in mind that that the Id from product is the row key for the Azure table.
            //* Returns a ProduectEntity class
            var productEntity = await _productRepository.GetItem(ProductPartitionKey,
                               productId.ToString(), correlationToken);

            if (productEntity == null)
            {
                _logger.LogWarning($"Cannot locate product information for item {productId}. Have you created the Product Read Model for the Shopping Basket microservice?");
                throw new Exception($"Cannot add item to shopping basket: Product #{productId} does not exist.  Have you created the Product Read Model for the Shopping Basket microservice?");
            }

            //* Transfrom ProductEntity class to Product
            product.Id = productEntity.Id;
            product.Title = productEntity.Title;
            product.ArtistName = productEntity.ArtistName;
            product.GenreName = productEntity.GenreName;
            product.Price = decimal.Parse(productEntity.Price);
            product.ReleaseDate = productEntity.ReleaseDate;
            product.Cutout = productEntity.Cutout;
            product.Upc = productEntity.Upc;
            product.ParentalCaution = productEntity.ParentalCaution;
            //******************************************************************************

            if (product == null)
            {
                _logger.LogWarning($"Cannot locate product information for item {productId}");
                throw new Exception($"Cannot add item to shopping basket: Product #{productId} does not exist.");
            }

            
            if (basketItem != null)
            {
                // Basket already contains this item - increase quanity
                basketItem.Count++;
                _logger.LogInformation("Added product Id {id} to existing shopping basket {basket} for request {token}",
                    productId, basketId, correlationToken);
            }
            else
            {
                // Create new shopping basket entry
                basketItem = new BasketItemEntity
                {
                    PartitionKey = basketId,
                    RowKey = productId.ToString(),
                    CorrelationToken = correlationToken,
                    DateCreated = DateTime.Now,
                    Item = product.Title,
                    // Azure Table Storage not support Decimal types - convert to string for storage
                    Price = product.Price.ToString(),
                    Artist = product.ArtistName,
                    Genre = product.GenreName,
                    ParentalCaution = product.ParentalCaution,
                    Count = 1
                };

                _logger.LogInformation("Created new shopping basket for request {token} and added product {id}",
                    correlationToken, productId);
            }

            // Add to storage
            await _basketRepository.Update(basketItem, correlationToken);

            return basketItem;
        }

        /// <summary>
        ///     Removes single line item from shopping basket
        /// </summary>
        /// <param name="productId">Id of product to add</param>
        /// <param name="correlationToken">Tracks request - can be any value</param>
        /// <param name="basketId">Id of shopping basket</param>
        /// <returns>BasketItemRemoveEntity</returns>
        public async Task<BasketItemRemoved> RemoveItemFromBasket(string basketId, int productId, string correlationToken)
        {
            // Get reference to shopping basket item
            // Note that we pass correlationToken as parameter for logging - not searching
            var basketItem = await _basketRepository.GetItem(basketId, productId.ToString(), correlationToken);

            if (basketItem == null)
            {
                // Shopping basket item does not request
                _logger.LogWarning("Cound not locate shopping basket {id} for request {token}", productId,
                    correlationToken);
                return null;
            }

            // Determine quanity of item in basket
            // Keep in mind that a shopping basket item can have a quanity of more than one 
            if (basketItem.Count > 1)
            {
                // If multiple identical items are in basket, remove 1 provided that the correlation token for the 
                // current record in Basket is different from the current correlation token. If correlation token 
                // is the same, then we have already removed this item.
                if (basketItem.CorrelationToken != correlationToken )
                {
                    // Decrement quanity on line item by 1
                    basketItem.Count--;
                    // reset the correlation token to that of the current correlation token value
                    basketItem.CorrelationToken = correlationToken;
                    await _basketRepository.Update(basketItem, correlationToken);
                    _logger.LogInformation("Removed product Id {id} from shopping basket {basket} for request {token}",
                        productId, basketId, correlationToken);
                }
            }
            else
            {
                // Here, the line item has a quanity of 1. Remove the line item from the basket.
                await _basketRepository.Delete(basketId, productId.ToString(), correlationToken);
                basketItem.Count = 0;
                _logger.LogInformation("Removed both product Id {id} and shopping basket {basket} for request {token}",
                    productId, basketId, correlationToken);

                // Wait 1 second for Azure Storage Table delete to occur 
                Thread.Sleep(1000);
            }

            // Calculate basket count and total
            var basket = await _basketRepository.GetList(basketId);

            // Construct return type
            var basketItemRemoved = new BasketItemRemoved
            {
                Message = $"{basketItem.Item} has been removed from your shopping basket.",
                DeleteId = productId,
                // ItemCount is the remaining number of identical items that were just removed
                ItemCount = basketItem.Count,
                BasketCount = basket.Count,
                BasketTotal = basket.Sum(x => decimal.Parse(x.Price))
            };

            return basketItemRemoved;
        }

        /// <summary>
        ///     Removes entire shopping basket
        /// </summary>
        /// <param name="basketId">Identifier for Basket</param>
        /// <param name="correlationToken">Tracks request - can be any value</param>
        /// <param name="hasOrderBeenCreated">Flag that indicates is basket emptied for new order</param>
        public async Task EmptyBasket(string basketId, string correlationToken, bool hasOrderBeenCreated)
        {
            // Get all Basket items for basketId
            var basket = await _basketRepository.GetList(basketId);

            // Enumerate shopping basket list removing each line item 
            foreach (var item in basket)
            {
                // Derive productId which is mapped to the Storage Table's Row Key
                var productId = int.Parse(item.RowKey);
                var itemCount = item.Count;

                // Remove shopping basket line item from data store
                await _basketRepository.Delete(item.PartitionKey, item.RowKey, correlationToken);

                _logger.LogInformation("Removed shopping basket {basket} for request {token}", basketId,
                    correlationToken);
            }
        }

        /// <summary>
        ///     Invokes check-out process
        /// </summary>
        /// <param name="orderInformation">User information to create new order</param>
        /// <param name="correlationToken">Tracks request - can be any value</param>
        /// <returns></returns>
        public async Task<bool> Checkout(OrderInformation orderInformation, string correlationToken)
        {
            var total = 0m;
            var basketId = orderInformation.BasketId;
            var orderDetails = new List<OrderDetail>();

            // TODO: Capture UserID from Security Prinicpal
            //var userName = ClaimsPrincipal.Current.Identity.Name ?? "Generic User";
            //https://davidpine.net/blog/principal-architecture-changes/
            var userName = "Generic User";

            // Create buyer information object
            var buyer = new BuyerInformation
            {
                Address = orderInformation.Address,
                City = orderInformation.City,
                Email = orderInformation.Email,
                FirstName = orderInformation.FirstName,
                LastName = orderInformation.LastName,
                Phone = orderInformation.Phone,
                PostalCode = orderInformation.PostalCode,
                State = orderInformation.State,
                Username = orderInformation.Username
            };

            // Get basket details and create new order
            var basketItems = await GetBasketItems(basketId, correlationToken);

            foreach (var item in basketItems)
                orderDetails.Add(new OrderDetail
                {
                    AlbumId = int.Parse(item.RowKey),
                    OrderId = basketId,
                    Quantity = item.Count,
                    UnitPrice = decimal.Parse(item.Price),
                    Item = item.Item,
                    Artist = item.Artist
                });

            // Create event class that will contain the required shopping basket and 
            // buyer information to create a new order.
            var checkout = new UserCheckoutEvent
            {
                BasketId = basketId,
                UserName = userName,
                OrderDate = DateTime.Now,
                Total = orderDetails.Sum(x => x.UnitPrice),
                BuyerInformation = buyer,
                OrderDetails = orderDetails
            };

            _logger.LogInformation("User issued check-out operation for shopping basket {basket} for request {token}",
                basketId, correlationToken);

            //************** Publish Event  *************************
            // Publish customer checkout event
            // Ordering subscribes to event and creates order. 
            // Once created, Ordering publishes event to have Basket remove basket.
            await _eventBus.Publish(checkout,
                MessageEventEnum.UserCheckoutEvent,
                correlationToken);

            return true;
        }

        /// <summary>
        ///     Event handler that listens for PrdouctChanged Events from the catalog service
        ///     and synchronizes the Catalog Read Table in Basket accordingly.
        ///     Handles both product inserts and updates.
        /// </summary>
        /// <param name="product">Product Information</param>
        /// <param name="correlationId">Tracks request - can be any value</param>
        /// <returns></returns>
        public async Task ProductChanged(Product product, string correlationId)
        {
            if (product == null)
            {
                _logger.LogWarning($"Missing product information for synchronization event in Basket");
                throw new Exception($"Missing product information for synchronization event in Basket");
            }

            // Transform to ProductEntity objects
            var productEntity = new ProductEntity
            {
                PartitionKey = ProductPartitionKey,
                RowKey = product.Id.ToString(),
                Title = product.Title,
                ArtistName = product.ArtistName,
                Cutout = product.Cutout,
                GenreName = product.GenreName,
                ParentalCaution = product.ParentalCaution,
                Price = product.Price.ToString(),
                ReleaseDate = product.ReleaseDate,
                Upc = product.Upc
            };

            try
            {
                // Determine if record already exists
                var currentReadTableItems =
                     await _productRepository.GetItem(ProductPartitionKey,
                     productEntity.RowKey, correlationId);

                if (currentReadTableItems == null)
                    await _productRepository.Insert(productEntity, correlationId);
                else
                    await _productRepository.Update(productEntity, correlationId);
            }
            catch (Exception ex)
            {
                _logger.LogError(new EventId(ex.HResult),
                    ex,
                    "Exception throw in ProductChanged() in Basket : {message}", ex.Message);

                throw new Exception($"Error in ProductChanged() in Basket : {ex.Message}");
            }

            await Task.CompletedTask;
        }
    }
}