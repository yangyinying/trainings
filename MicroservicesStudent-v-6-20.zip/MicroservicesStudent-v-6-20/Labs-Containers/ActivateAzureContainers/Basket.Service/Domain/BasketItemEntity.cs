﻿using System;
using Microsoft.WindowsAzure.Storage.Table;

namespace Basket.API.Domain
{
    /// <summary>
    ///     This class maps to an Azure Table Entity
    ///     BasketId => Partition Key
    ///     ProductId => Row Key
    /// </summary>
    public class BasketItemEntity : TableEntity
    {
        public int UserId { get; set; }
        public string CorrelationToken { get; set; }
        public string Item { get; set; }
        public string Artist { get; set; }
        public string Genre { get; set; }
        public string Price { get; set; }
        public int Count { get; set; }
        public bool ParentalCaution { get; set; }
        public DateTime DateCreated { get; set; }
    }
}