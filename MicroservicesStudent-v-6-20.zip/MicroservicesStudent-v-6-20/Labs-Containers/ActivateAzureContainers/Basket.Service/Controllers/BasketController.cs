﻿using System.Collections.Generic;
using System.Net;
using System.Threading.Tasks;
using Basket.API.Application.Dtos;
using Basket.API.Contracts;
using Basket.API.Domain;
using Microsoft.AspNetCore.Mvc;
using Utilities;

namespace Basket.API.Controllers
{
    /// <summary>
    ///     Microservice that manages the Shopping Basket experience
    /// </summary>
    [Route("api/[controller]")]
    public class BasketController : Controller
    {
        private readonly IBasketBusinessServices _basketBusinessServices;

        public BasketController(IBasketBusinessServices basketBusinessServices)
        {
            _basketBusinessServices = basketBusinessServices;
        }

        /// <summary>
        ///     Gets all shopping baskets.
        /// </summary>
        /// <param name="correlationToken">Tracks request - Can be any value</param>
        /// <returns>List of line items that make up a shopping basket</returns>
        [ProducesResponseType(typeof(List<BasketDto>), 200)]
        [HttpGet("Baskets/{correlationToken}", Name = "GetAllbasketsRoute")]
        public async Task<IActionResult> GetAllBaskets(string correlationToken)
        {
            Guard.ForNullOrEmpty(correlationToken, "correlationToken");

            var baskets = await _basketBusinessServices.GetAllBaskets(correlationToken);

            var basketDtos = Mapper.MapToBasketDto(baskets);

            return new ObjectResult(basketDtos);
        }

        /// <summary>
        ///     Get all line items for a user's shopping basket
        /// </summary>
        /// <param name="basketId">Identifier for user shopping basket</param>
        /// <param name="correlationToken">Tracks request - Can be any value</param>
        /// <returns>List of line items that make up a shopping basket</returns>
        [ProducesResponseType(typeof(List<BasketItemDto>), 200)]
        [HttpGet("Basket/{BasketId}/{correlationToken}", Name = "GetbasketRoute")]
        public async Task<IActionResult> GetBasket(string basketId, string correlationToken)
        {
            Guard.ForNullOrEmpty(basketId, "BasketId");
            Guard.ForNullOrEmpty(correlationToken, "correlationToken");

            var basket = await _basketBusinessServices.GetBasketItems(basketId, correlationToken);

            if (basket == null || basket.Count < 1)
                return new ObjectResult(basket);
            //return Ok(new List<BasketItemDto>());

            var basketDto = Mapper.MapToBasketDto(basket);

            return new ObjectResult(basketDto);
        }

        /// <summary>
        ///     Removes line item from the shopping basket
        /// </summary>
        /// <param name="basketId">Identifier for user shopping basket</param>
        /// <param name="productId">Product Identifier</param>
        /// <param name="correlationToken">Identifier for user shopping basket</param>
        /// <returns>Summary of shopping basket state</returns>
        [HttpDelete("{BasketId}/lineitem/{productId}")]
        public async Task<IActionResult> DeleteLineItem(string basketId, int productId, string correlationToken)
        {
            Guard.ForNullOrEmpty(basketId, "BasketId");
            Guard.ForLessEqualZero(productId, "ProductId");
            Guard.ForNullOrEmpty(correlationToken, "correlationToken");

            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            var basket = await _basketBusinessServices.RemoveItemFromBasket(basketId, productId, correlationToken);

            return Ok(basket);
        }

        /// <summary>
        ///     Adds a new line item to the user's shopping basket
        /// </summary>
        /// <param name="product">Product Information</param>
        /// <param name="productId">Product Identifier</param>
        /// <param name="correlationToken">Tracks request - Can be any value</param>
        /// <param name="basketId">Identifier for user shopping basket</param>
        /// <returns>The newly-created line item</returns>
        [ProducesResponseType(typeof(BasketItemDto), 200)]
        [HttpPost]
        public async Task<IActionResult> AddBasketItem([FromBody] Product product, string basketId, int productId,
            string correlationToken)
        {
            Guard.ForLessEqualZero(productId, "ProductId");
            Guard.ForNullOrEmpty(basketId, "BasketId");
            Guard.ForNullOrEmpty(correlationToken, "correlationToken");

            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            var basket = await _basketBusinessServices.AddItemToBasket(product, productId, correlationToken, basketId);

            // Map to DTO
            var basketDto = Mapper.MapToBasketDto(basket);

            return new ObjectResult(basketDto);
        }

        /// <summary>
        ///     Converts Shopping Basket to Order
        /// </summary>
        /// <param name="newOrderDto">New Order information</param>
        /// <param name="correlationToken">Tracks request - Can be any value</param>
        /// <returns>The newly-created line item</returns>
        [ProducesResponseType(typeof(NewOrderDto), 200)]
        [HttpPost("CheckOut")]
        public async Task<IActionResult> PosttCheckOut([FromBody] NewOrderDto newOrderDto, string correlationToken)
        {
            Guard.ForNullObject(newOrderDto, "NewOrder");
            Guard.ForNullOrEmpty(newOrderDto.BasketId, "BasketId in New Order");
            Guard.ForNullOrEmpty(correlationToken, "CorrleationToken");

            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            // Ensure that ShoppingBasket exists before executing Checkout operation
            var basket = await _basketBusinessServices.GetBasketItems(newOrderDto.BasketId, correlationToken);

            if (basket.Count < 1)
                return null;

            // Map OrderDto to Order
            var newOrder = Mapper.MapToOrderInformation(newOrderDto);

            // Call into service
            await _basketBusinessServices.Checkout(newOrder, correlationToken);

            // Returns 202 status code
            return new ObjectResult(new NewOrderDto());
            //return Accepted("Order is being created");
        }

        /// <summary>
        ///     Removes entire shopping basket, including all line items
        /// </summary>
        /// <param name="basketId">Identifier for user shopping basket</param>
        /// <param name="correlationToken">Tracks request - Can be any value</param>
        /// <returns></returns>
        [HttpDelete]
        public async Task<HttpStatusCode>  Delete(string basketId, string correlationToken)
        {
            Guard.ForNullOrEmpty(basketId, "BasketId");
            Guard.ForNullOrEmpty(correlationToken, "correlationToken");

            _basketBusinessServices.EmptyBasket(basketId, correlationToken, false);
            return HttpStatusCode.NoContent;
        }
    }
}