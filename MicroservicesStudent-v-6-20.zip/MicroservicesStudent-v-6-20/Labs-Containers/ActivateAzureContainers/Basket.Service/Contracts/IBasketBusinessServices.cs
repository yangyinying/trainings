﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Basket.API.Domain;

namespace Basket.API.Contracts
{
    public interface IBasketBusinessServices
    {
        Task<List<BasketItemEntity>> GetAllBaskets(string correlationToken);
        Task<List<BasketItemEntity>> GetBasketItems(string basketId, string corrleationId);
        Task<BasketItemEntity> AddItemToBasket(Product product, int productId, string correlationToken, string basketId);
        Task<BasketItemRemoved> RemoveItemFromBasket(string basketId, int productId, string correlationToken);
        Task EmptyBasket(string basketId, string correlationToken, bool hasOrderBeenCreated);
        Task<bool> Checkout(OrderInformation orderInformation, string correlationToken);
        Task ProductChanged(Product product, string correlationId);
    }
}