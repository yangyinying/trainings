﻿using System.Collections.Generic;
using System.Linq;
using Basket.API.Domain;

namespace Basket.API.Application.Dtos
{
    public class Mapper
    {
        public static BasketItemDto MapToBasketDto(BasketItemEntity basket)
        {
            return new BasketItemDto
            {
                BasketId = basket.PartitionKey,
                ProductId = int.Parse(basket.RowKey),
                UserId = basket.UserId,
                Genre = basket.Genre,
                Name = basket.Item,
                Artist = basket.Artist,
                // Price equates to price times number of identical items
                // We store decimal types as string in Azure Storage. Convert here.
                Price = decimal.Parse(basket.Price) * basket.Count,
                QuanityOrdered = basket.Count,
                Etag = basket.ETag,
                ParentalCaution = basket.ParentalCaution
            };
        }

        public static List<BasketDto> MapToBasketDto(IEnumerable<BasketItemEntity> baskets)
        {
            var totalPrice = 0m;
            var basketDtos = new List<BasketDto>();

            // Group baskets by Partition Key, which is mapped to BasketID
            var groupedBaskets = baskets.GroupBy(x => x.PartitionKey);

            foreach (var basket in groupedBaskets)
            {
                var basketDto = new BasketDto
                {
                    BasketId = basket.Key
                };

                foreach (var item in basket)
                    basketDto.CartItems.Add(new BasketItemDto
                    {
                        Artist = item.Artist,
                        BasketId = item.PartitionKey,
                        QuanityOrdered = item.Count,
                        Name = item.Item,
                        Price = decimal.Parse(item.Price),
                        Genre = item.Genre,
                        Etag = item.ETag,
                        ParentalCaution = item.ParentalCaution,
                        ProductId = int.Parse(item.RowKey)
                    });

                basketDto.CartTotal = basket.Sum(x => decimal.Parse(x.Price) * x.Count);
                basketDto.ItemCount = basket.Count();
                basketDtos.Add(basketDto);
            }

            return basketDtos;
        }

        public static OrderInformation MapToOrderInformation(NewOrderDto order)
        {
            return new OrderInformation
            {
                BasketId = order.BasketId,
                Address = order.Address,
                Email = order.Email,
                LastName = order.LastName,
                FirstName = order.FirstName,
                State = order.State,
                PostalCode = order.PostalCode,
                Phone = order.Phone,
                City = order.City,
                PromoCode = order.PromoCode,
                Total = order.Total
            };
        }
    }
}