﻿using Basket.API.Contracts;
using Basket.API.Domain;
using Basket.API.Infrastructure.Repository;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace Basket.API.Application.StartupExtensions
{
    public static class StorageExtension
    {
        public static IServiceCollection RegisterStorageAccount(
            this IServiceCollection services,
            IConfiguration configuration)
        {
            // Add Repository class for shopping basket to the DI container 
            services.AddScoped<IBaseRespository<BasketItemEntity>>(factory =>
            {
                return new BaseRespository<BasketItemEntity>(
                    new AzureTableSettings(
                        configuration["StorageAccount"],
                        configuration["StorageKey"],
                        configuration["StorageTableName_Basket"]));
            });

            // Add Repository class for product read table to the DI container 
            services.AddScoped<IBaseRespository<ProductEntity>>(factory =>
            {
                return new BaseRespository<ProductEntity>(
                    new AzureTableSettings(
                        configuration["StorageAccount"],
                        configuration["StorageKey"],
                        configuration["StorageTableName_Catalog"]));
            });

            return services;
        }
    }
}