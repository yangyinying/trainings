﻿using System.Threading.Tasks;
using Ordering.Domain.AggregateModels.BuyerAggregate;
using Ordering.Domain.Contracts;

namespace Ordering.API.Commands
{
    public class CreateBuyerCommandHandler
    {
        private readonly IBuyerRepository _buyerRepository;

        public CreateBuyerCommandHandler(IBuyerRepository buyerRepository)
        {
            _buyerRepository = buyerRepository;
        }

        public async Task<bool> Handle(CreateBuyerCommand createBuyerCommand)
        {
            // Create Order domain aggregate
            var buyer = new Buyer(createBuyerCommand.OrderId,
                createBuyerCommand.UserName,
                createBuyerCommand.FirstName,
                createBuyerCommand.LastName,
                createBuyerCommand.Address,
                createBuyerCommand.City,
                createBuyerCommand.State,
                createBuyerCommand.PostalCode,
                createBuyerCommand.Country,
                createBuyerCommand.Phone,
                createBuyerCommand.Email);

            //Add Order to DataStore
            _buyerRepository.Add(buyer);
            return true;
        }
    }
}