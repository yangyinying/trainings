﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MusicStore.Helper
{
    public static class ToastrMessage
    {
        public static string Success => "Toastr.Success";
    }
}
