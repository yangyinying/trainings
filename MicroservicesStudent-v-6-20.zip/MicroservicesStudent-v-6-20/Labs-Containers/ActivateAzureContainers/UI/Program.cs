using Microsoft.AspNetCore;
using Microsoft.AspNetCore.Hosting;

namespace MusicStore
{
    public static class Program
    {
        public static void Main(string[] args)
        {
            BuildWebHost(args).Run();
        }

        public static IWebHost BuildWebHost(string[] args)
        {
            return WebHost.CreateDefaultBuilder(args)
                .UseAzureAppServices()
                .UseStartup<Startup>()
                .UseApplicationInsights()
                .Build();
        }
    }
}