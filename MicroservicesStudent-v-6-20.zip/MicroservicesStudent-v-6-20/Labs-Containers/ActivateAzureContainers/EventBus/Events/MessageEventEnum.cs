﻿namespace EventBus.Events
{
    public enum MessageEventEnum
    {
        ProductChangedEvent,
        PriceChangedEvent,
        UserCheckoutEvent,
        InvokeEmptyBasketEvent
    }
}