﻿namespace ApiGateway.API.Dtos.Catalog
{
    public class ArtistDto
    {
        public int ArtistId { get; set; }
        public string Name { get; set; }
    }
}