﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Basket.API.Contracts;
using EventBus.EventBus;
using EventBus.Events;
using Microsoft.Extensions.Logging;
using RestCommunication;
using ServiceDiscovery;

namespace Basket.API.Domain
{
    /// <summary>
    ///     Shopping basket domain business object
    /// </summary>
    public class BasketBusinessServices : IBasketBusinessServices
    {
        private const string ProductPartitionKey = "MusicProduct";
        private readonly IBaseRespository<BasketItemEntity> _basketRepository;
        private readonly ILogger _logger;
        private readonly IBaseRespository<ProductEntity> _productRepository;
        private readonly IRestClient _restClient;

        public BasketBusinessServices(IBaseRespository<BasketItemEntity> basketRepository,
            IBaseRespository<ProductEntity> productRepository,
            ILogger<BasketBusinessServices> logger,
            IRestClient restClient)
        {
            _basketRepository = basketRepository;
            _productRepository = productRepository;
            _logger = logger;
            _restClient = restClient;
        }

        /// <summary>
        ///     Get all shopping baskets
        /// </summary>
        /// <param name="correlationToken">Tracks request - can be any value</param>
        /// <returns>BasketItemEntity</returns>
        public async Task<List<BasketItemEntity>> GetAllBaskets(string correlationToken)
        {
            var basket = await _basketRepository.GetList(correlationToken);
            return basket;
        }

        /// <summary>
        ///     Gets specified shopping basket by Basket Id
        /// </summary>
        /// <param name="correlationToken">Tracks request - can be any value</param>
        /// <param name="basketId">Id of shopping basket</param>
        /// <returns>BasketItemEntity</returns>
        public async Task<List<BasketItemEntity>> GetBasketItems(string basketId, string correlationToken)
        {
            var basket = await _basketRepository.GetList(basketId, correlationToken);
            return basket;
        }

        /// <summary>
        ///     Add single line item to shopping basket
        /// </summary>
        /// <param name="product">Product to add</param>
        /// <param name="productId">Id of product to add</param>
        /// <param name="correlationToken">Tracks request - can be any value</param>
        /// <param name="basketId">Id of shopping basket</param>
        /// <returns>BasketItemEntity</returns>
        public async Task<BasketItemEntity> AddItemToBasket(Product product, int productId, string correlationToken,
            string basketId)
        {
            // Determine if item already exists in shopping basket
            var basketItem = await _basketRepository.GetItem(basketId, productId.ToString(), correlationToken);

            if (product == null)
            {
                _logger.LogWarning($"Cannot locate product information for item {productId}");
                throw new Exception($"Cannot add item to shopping basket: Product #{productId} does not exist.");
            }

            
            if (basketItem != null)
            {
                // Basket already contains this item - increase quanity
                basketItem.Count++;
                _logger.LogInformation("Added product Id {id} to existing shopping basket {basket} for request {token}",
                    productId, basketId, correlationToken);
            }
            else
            {
                // Create new shopping basket entry
                basketItem = new BasketItemEntity
                {
                    PartitionKey = basketId,
                    RowKey = productId.ToString(),
                    CorrelationToken = correlationToken,
                    DateCreated = DateTime.Now,
                    Item = product.Title,
                    // Azure Table Storage not support Decimal types - convert to string for storage
                    Price = product.Price.ToString(),
                    Artist = product.ArtistName,
                    Genre = product.GenreName,
                    ParentalCaution = product.ParentalCaution,
                    Count = 1
                };

                _logger.LogInformation("Created new shopping basket for request {token} and added product {id}",
                    correlationToken, productId);
            }

            // Add to storage
            await _basketRepository.Update(basketItem, correlationToken);

            return basketItem;
        }

        /// <summary>
        ///     Removes single line item from shopping basket
        /// </summary>
        /// <param name="productId">Id of product to add</param>
        /// <param name="correlationToken">Tracks request - can be any value</param>
        /// <param name="basketId">Id of shopping basket</param>
        /// <returns>BasketItemRemoveEntity</returns>
        public async Task<BasketItemRemoved> RemoveItemFromBasket(string basketId, int productId, string correlationToken)
        {
            // Step #1: Get reference to shopping basket item
            var basketItem = await _basketRepository.GetItem(basketId, productId.ToString(), correlationToken);

            if (basketItem == null)
            {
                _logger.LogWarning("Cound not locate shopping basket {id} for request {token}", productId,
                    correlationToken);
                return null;
            }

             // Determine quanity of item in basket
            if (basketItem.Count > 1)
            {
                // If multiple identical items are in basket, remove 1
                basketItem.Count--;
                await _basketRepository.Update(basketItem, correlationToken);
                _logger.LogInformation("Removed product Id {id} from shopping basket {basket} for request {token}",
                    productId, basketId, correlationToken);
            }
            else
            {
                await _basketRepository.Delete(basketId, productId.ToString(), correlationToken);
                basketItem.Count = 0;
                _logger.LogInformation("Removed both product Id {id} and shopping basket {basket} for request {token}",
                    productId, basketId, correlationToken);

                // Wait 1 second for table delete to occur 
                Thread.Sleep(1000);
            }

            // Calculate basket count and total
            var basket = await _basketRepository.GetList(basketId);

            // Construct return type
            var basketItemRemoved = new BasketItemRemoved
            {
                Message = $"{basketItem.Item} has been removed from your shopping basket.",
                DeleteId = productId,
                // ItemCount is the remaining number of identical items that were just removed
                ItemCount = basketItem.Count,
                BasketCount = basket.Count,
                BasketTotal = basket.Sum(x => decimal.Parse(x.Price))
            };

            return basketItemRemoved;
        }

        /// <summary>
        ///     Removes entire shopping basket
        /// </summary>
        /// <param name="basketId">Identifier for Basket</param>
        /// <param name="correlationToken">Tracks request - can be any value</param>
        /// <param name="hasOrderBeenCreated">Flag that indicates is basket emptied for new order</param>
        public async Task EmptyBasket(string basketId, string correlationToken, bool hasOrderBeenCreated)
        {
            // Get all Basket items for basketId
            var basket = await _basketRepository.GetList(basketId);

            // Enumerate shopping basket list removing each line item 
            foreach (var item in basket)
            {
                // Derive productId which is mapped to the Storage Table's Row Key
                var productId = int.Parse(item.RowKey);
                var itemCount = item.Count;

                // Remove shopping basket line item from data store
                await _basketRepository.Delete(item.PartitionKey, item.RowKey, correlationToken);

                _logger.LogInformation("Removed shopping basket {basket} for request {token}", basketId,
                    correlationToken);
            }
        }

        /// <summary>
        ///     Invokes check-out process
        /// </summary>
        /// <param name="orderInformation">User information to create new order</param>
        /// <param name="correlationToken">Tracks request - can be any value</param>
        /// <returns></returns>
        public async Task<bool> Checkout(OrderInformation orderInformation, string correlationToken)
        {
			throw new System.NotImplementedException();
        }

        /// <summary>
        ///     Event handler that listens for PrdouctChanged Events from the catalog service
        ///     and synchronizes the Catalog Read Table in Basket accordingly.
        ///     Handles both product inserts and updates.
        /// </summary>
        /// <param name="product">Product Information</param>
        /// <param name="correlationId">Tracks request - can be any value</param>
        /// <returns></returns>
        public async Task ProductChanged(Product product, string correlationId)
        {
            throw new System.NotImplementedException();
        }


    }
}