﻿using System;
using System.Text;
using System.Threading.Tasks;
using Basket.API.Contracts;
using Basket.API.Domain;
using EventBus.Events;
using Microsoft.Azure.ServiceBus;
using Newtonsoft.Json;

namespace Basket.API.Events
{
       /// <summary>
    ///     Handles ProductChanged Event rasied from Catalog Service
    /// </summary>
    public class ProductChangedEventHandler : IIntegratedEventHandler
    {

        public async Task HandleAsync(Message message)
        {
            throw new NotImplementedException();
        }
    }
}